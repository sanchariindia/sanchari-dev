<style>

.sidebar-menu > li > a{padding:5px 5px 8px 15px !important;}

</style>

<aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
<li class="">
<a href="home.php">
<i class="fa fa-dashboard"></i> <span>Dashboard</span>
<span class="pull-right-container">
<i class="fa fa-angle-left pull-right"></i>
</span>
</a>
</li>

<li>
<a href="enquiry.php">
<i class="fa fa-files-o"></i>
<span>Enquiry</span>
</a>
</li>


<li>
<a href="addservice.php">
<i class="fa fa-files-o"></i>
<span>Add Services</span>
</a>
</li>

<li>
<a href="services.php">
<i class="fa fa-files-o"></i>
<span>View Services</span>
</a>
</li>

<li>
<a href="addproduct.php">
<i class="fa fa-files-o"></i>
<span>Add Places</span>
</a>
</li>

<li>
<a href="products.php">
<i class="fa fa-files-o"></i>
<span>View Places</span>
</a>
</li>

<li>
<a href="addslide.php">
<i class="fa fa-files-o"></i>
<span>Slider Management</span>
</a>
</li>

<li>
<a href="clients.php">
<i class="fa fa-files-o"></i>
<span>Clients Management</span>
</a>
</li>

<li>
<a href="gallery.php">
<i class="fa fa-files-o"></i>
<span>Gallery Management</span>
</a>
</li>


<li>
<a href="contact.php">
<i class="fa fa-files-o"></i>
<span>Contact Management</span>
</a>
</li>

      </ul>
    </section>
  </aside>